const str1 = "Hello";
const str2 = "World";
module.exports={
    first:str1,
    second:str2,
    date:Date()
}